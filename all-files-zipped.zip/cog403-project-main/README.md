# cog403-project
Code component of my COG403 Final project. Implements a Hidden Markov Model as a Bayesian-like way of tagging parts of speech from a labelled dataset.
Supports the Final report entitled "Comparing Bayesian and Connectionist Models in Speech Generation".
